package io.github.smiley4.schemakenerator.swagger

import io.github.smiley4.schemakenerator.core.data.AnnotationData
import io.github.smiley4.schemakenerator.core.data.TypeData
import io.github.smiley4.schemakenerator.core.data.TypeId
import io.github.smiley4.schemakenerator.swagger.SwaggerSchemaAnnotationUtils.iterateProperties
import io.github.smiley4.schemakenerator.swagger.SwaggerSchemaAnnotationUtils.removePropertyIf
import io.github.smiley4.schemakenerator.swagger.data.IntermediateSwaggerSchemaData
import io.github.smiley4.schemakenerator.swagger.data.SwaggerSchemaData
import io.swagger.v3.oas.annotations.media.Schema
import java.math.BigDecimal

internal class SwaggerSchemaAnnotationStep {

    fun process(input: IntermediateSwaggerSchemaData): IntermediateSwaggerSchemaData {
        input.entries.forEach { process(it, input.typeDataById) }
        return input
    }

    @Suppress("CyclomaticComplexMethod")
    private fun process(schema: SwaggerSchemaData, typeDataMap: Map<TypeId, TypeData>) {
        getTitle(schema.typeData.annotations)?.also { schema.swagger.title = it }
        getDescription(schema.typeData.annotations)?.also { schema.swagger.description = it }

        removePropertyIf(schema) { _, data ->
            getHidden(data.annotations) ?: false
        }

        iterateProperties(schema, typeDataMap) { prop, propData, propTypeData ->
            val mergedAnnotations = propData.annotations + propTypeData.annotations
            getTitle(mergedAnnotations)?.also { prop.title = it }
            getDescription(mergedAnnotations)?.also { prop.description = it }
            getExample(mergedAnnotations)?.also { prop.example = it }
            getAllowableValues(mergedAnnotations)?.onEach { entry ->
                @Suppress("UNCHECKED_CAST")
                (prop as io.swagger.v3.oas.models.media.Schema<Any>).addEnumItemObject(entry)
            }
            getDefaultValue(mergedAnnotations)?.also { prop.setDefault(it) }
            getAccessMode(mergedAnnotations)?.also {
                when(it) {
                    Schema.AccessMode.AUTO -> Unit
                    Schema.AccessMode.READ_ONLY -> prop.readOnly = true
                    Schema.AccessMode.WRITE_ONLY -> prop.writeOnly = true
                    Schema.AccessMode.READ_WRITE -> {
                        prop.readOnly = false
                        prop.writeOnly = false
                    }
                }
            }
            getRequiredMode(mergedAnnotations)?.also {
                when(it) {
                    Schema.RequiredMode.AUTO -> Unit
                    Schema.RequiredMode.REQUIRED -> {
                        if(!schema.swagger.required.contains(prop.name)) {
                            schema.swagger.required.add(prop.name)
                        }
                    }
                    Schema.RequiredMode.NOT_REQUIRED -> {
                        schema.swagger.required.remove(propData.name)
                    }
                }
            }
            getMinLength(mergedAnnotations)?.also { prop.minLength = it }
            getMaxLength(mergedAnnotations)?.also { prop.maxLength = it }
            getFormat(mergedAnnotations)?.also { prop.format = it }
            getMinimum(mergedAnnotations)?.also { prop.minimum = it }
            getMaximum(mergedAnnotations)?.also { prop.maximum = it }
            isExclusiveMinimum(mergedAnnotations)?.also { prop.exclusiveMinimum = it }
            isExclusiveMaximum(mergedAnnotations)?.also { prop.exclusiveMaximum = it }
            getName(mergedAnnotations)?.also {
                prop.name = it
                propData.name = it
            }
        }
    }

    private fun getTitle(annotations: Collection<AnnotationData>): String? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["title"] as String }
            .firstOrNull { it.isNotBlank() }
    }

    private fun getDescription(annotations: Collection<AnnotationData>): String? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["description"] as String }
            .firstOrNull { it.isNotBlank() }
    }

    private fun getExample(annotations: Collection<AnnotationData>): String? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["example"] as String }
            .firstOrNull { it.isNotBlank() }
    }

    private fun getHidden(annotations: Collection<AnnotationData>): Boolean? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["hidden"] as Boolean }
            .firstOrNull { it }
    }

    private fun getName(annotations: Collection<AnnotationData>): String? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["name"] as String }
            .firstOrNull { it.isNotBlank() }
    }

    private fun getAllowableValues(annotations: Collection<AnnotationData>): List<String>? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map {
                @Suppress("UNCHECKED_CAST")
                it.values["allowableValues"] as Array<String>
            }
            .map { it.toList() }
            .firstOrNull { it.isNotEmpty() }
    }

    private fun getDefaultValue(annotations: Collection<AnnotationData>): String? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["defaultValue"] as String }
            .firstOrNull { it.isNotBlank() }
    }

    private fun getAccessMode(annotations: Collection<AnnotationData>): Schema.AccessMode? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["accessMode"] as Schema.AccessMode }
            .firstOrNull { it != Schema.AccessMode.AUTO }
    }

    private fun getRequiredMode(annotations: Collection<AnnotationData>): Schema.RequiredMode? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["requiredMode"] as Schema.RequiredMode }
            .firstOrNull { it != Schema.RequiredMode.AUTO }
    }


    private fun getMinLength(annotations: Collection<AnnotationData>): Int? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["minLength"] as Int }
            .firstOrNull { it != 0 }
    }

    private fun getMaxLength(annotations: Collection<AnnotationData>): Int? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["maxLength"] as Int }
            .firstOrNull { it != Int.MAX_VALUE  }
    }

    private fun getFormat(annotations: Collection<AnnotationData>): String? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["format"] as String }
            .firstOrNull { it.isNotBlank() }
    }

    private fun getMinimum(annotations: Collection<AnnotationData>): BigDecimal? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["minimum"] as String }
            .filter { it.isNotBlank() }
            .map { BigDecimal(it) }
            .firstOrNull()
    }

    private fun isExclusiveMinimum(annotations: Collection<AnnotationData>): Boolean? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["exclusiveMinimum"] as Boolean }
            .firstOrNull { it }
    }

    private fun getMaximum(annotations: Collection<AnnotationData>): BigDecimal? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["maximum"] as String }
            .filter { it.isNotBlank() }
            .map { BigDecimal(it) }
            .firstOrNull()
    }

    private fun isExclusiveMaximum(annotations: Collection<AnnotationData>): Boolean? {
        return annotations
            .filter { it.name == Schema::class.qualifiedName }
            .map { it.values["exclusiveMaximum"] as Boolean }
            .firstOrNull { it }
    }
}
